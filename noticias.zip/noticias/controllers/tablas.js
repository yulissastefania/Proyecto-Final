
'use strict';


function multiplicar(req, res) {

    var a = req.params.a;
    
    var tabla=""//'{title:"'+a+'",';
    
    for(var i=0;i<=12;i++){
        //var aux = parseInt(i*a);
        // tabla +='cont'+i+':"'+ i+' * '+a+' = '+(i*a); 
        //tabla += "<tr><td>"+i+" "+a+" = "+(i*a)+"</td></tr>";
        //if(!i==12){
          //  tabla+=',';
        //}
        tabla+= i +" * "+a+" = "+(i*a)+" || ";
        
        
    }
    //tabla+='}';
    var data={
      title:'tabla del: '+a,
      tabla:tabla
        
    };
    
    res.render('tablas',data);

}

module.exports = {multiplicar};





