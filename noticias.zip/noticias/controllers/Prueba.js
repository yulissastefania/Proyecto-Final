
'use strict';
//zona de importaciones
class PruebaController {
    constructor(){};
    suma(req,res){
        var a = parseInt(req.params.a);
        var b = parseInt(req.params.b);
        var c = a + b;
        res.render('acerca', { title: 'Suma', descripcion:'Las suma es:  '+c});
    }
}


module.exports = PruebaController;